<?php

global $wp_roles; 
$wp_roles->add_cap( 'administrator', 'edit_forms' ); 
