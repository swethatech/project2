<div class="hf-small-margin">
	<p><strong><?php _e( 'Looking for help?', 'html-forms' ); ?></strong>
		<?php echo sprintf( __('Check out the <a href="%s">HTML Forms knowledge base</a>', 'html-forms' ), 'https://kb.htmlforms.io/#utm_source=wp-plugin&utm_medium=html-forms&utm_campaign=admin-footer' ); ?>.</p>
</div>
