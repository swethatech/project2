<div>

	<div>
		<h3>Our other plugins</h3>
		<div style="margin: 12px 0;">
			<div><strong><a href="https://wordpress.org/plugins/mailchimp-for-wp/">MC4WP: Mailchimp for WordPress</a></strong></div>
			<div>The #1 Mailchimp plugin for WordPress.</div>
		</div>

		<div style="margin: 12px 0;">
			<div><strong><a href="https://wordpress.org/plugins/koko-analytics/">Koko Analytics</a></strong></div>
			<div>Privacy-friendly analytics plugin that does not use any external services.</div>
		</div>

		<div style="margin: 12px 0;">
			<div><strong><a href="https://wordpress.org/plugins/boxzilla/">Boxzilla Pop-ups</a></strong></div>
			<div>Pop-up or slide-in boxes that can be configured to show up at just the right time.</div>
		</div>
	</div>

</div>


